# VEE Codex handover kit

Start with Codex_Implementation_Prompts.md and Prompt 1.

Use the current project for implementation. application/ is a frozen verified reference snapshot: never extract it over newer user changes. research/framework-v0.2.1/ contains the integration contract and dossiers; research/expanded-discovery/ is only needed for the later staging milestone. Completed checks and limitations are documented inside the framework. Keep all work local.
