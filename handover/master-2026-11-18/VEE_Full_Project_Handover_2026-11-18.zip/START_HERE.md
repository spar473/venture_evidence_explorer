# Venture Evidence Explorer — full project handover

1. Read Code_Agent_Handover_v2_2026-11-18.md.
2. Use master-handover-2026-11-18/New_Chat_Prompt.txt to load a new chat.
3. For coding, prefer the actual current project. application/ is the frozen source verified for this handover; never extract it over newer user edits.
4. Verify source bytes using master-handover-2026-11-18/Source_Manifest.json. Build dependencies/assets separately in a disposable copy.

The latest F1–F3 fixes and dossier/discovery refinements are implemented; the older review/fix prompts are historical. Retrieval remains ten ventures; discovery contains 274 staged leads, with human evidence acceptance and relevance work still pending.

No live database, dependencies, compiled assets, private material or literal missing original Downloads handover are included. Everything remains local.
