# NZ venture research — first evidence batch

Prepared 17 November 2026. Research in progress; the application and its database were not changed.

The project can grow from its University of Auckland cohort into a historical NZ venture evidence collection. Portfolio pages are useful discovery lists, but dated company, investor and institutional records are needed to reconstruct what happened. This batch establishes that research format with ten ventures. It does not yet provide hundreds of ventures or complete coverage from 2000 onwards.

## What this batch contains

- Ten candidate ventures: two proposed links to existing UoA records (Alimetry and Formus Labs), plus eight new candidates.
- 29 source records, including seven directory/discovery pages. This is not 29 independent confirmations.
- 28 observations, 21 event records and 41 investor relationship claims. An event may be a retrospective report or name-history observation; this is not a count of funding rounds.
- Ten proposed investigation angles and 13 unresolved cases. Proposed angles are not accepted comparison features.
- Structural checks passed for identifiers, references, date formats and required unknowns. These checks do not establish issuer truth, legal identity or historical source availability.

The machine-readable companion is [Research_pack_01.json](Research_pack_01.json); [Validation_record.json](Validation_record.json) records the checks. The pack is a research interchange draft, not a direct application import.

## The ten venture starting points

| Venture | Product or business context reported by sources | Historical evidence captured | Important qualification |
|---|---|---|---|
| Alimetry | Gastric measurement wearable, symptom app and clinical analysis platform | [Company announcement](https://www.alimetry.com/press/alimetry-raises-an-oversubscribed-us-18m): US$18m A2, 25 October 2024 | [GD1](https://gd1.vc/notes/alimetry-investment-notes) describes $30m / Series A Expansion on the same day. Currency and scope need reconciliation before consolidation. |
| Formus Labs | Imaging and biomechanical modelling for joint replacement planning | [UoA article](https://www.auckland.ac.nz/en/news/2022/06/29/formuslabs-raises-towards-ai-powered-orthopaedic-surgery.html): US$5m in February 2022, led by GD1 | Article published in June; do not date the financing to June. Its discussion of IMeasureU concerns a founder’s earlier company. |
| Halter | Cattle collars and virtual fencing / herd management software | [Company announcement](https://www.halterhq.com/en-nz/news/halter-accelerates-international-expansion-following-seriese-fundraising-round): NZD377m Series E, 25 March 2026 | Company also gives US$220m as an equivalent. These are two presentations of one round. |
| Tracksuit | Continuous brand tracking for marketers | [Series A](https://www.gotracksuit.com/au/blog/posts/raise-announcement-series-a), February 2024; [Series B](https://www.gotracksuit.com/au/blog/posts/tracksuit-series-b-funding), June 2025 | Series A AU and UK editions use different currencies. The selected Series B page’s $25m lacks an explicit currency code. |
| Vessev | Battery-electric hydrofoil vessels and flight-control technology | [Company-issued release](https://www.prnewswire.com/news-releases/vessev-enters-us-market-with-19-million-series-a-names-first-us-customer-and-launches-multi-city-us-showcase-302856533.html), 20 August 2026: financing and first US customer announcement | $19m covers Series A **and follow-on** financing. Currency is unresolved. Customer announcement does not establish completed operations or first paid revenue. |
| Hnry | Tax, payments and financial administration for independent earners | [Company history](https://hnry.co.nz/about), 2019 financing, [Series B report](https://hnry.co.nz/resources/news/hnry-secures-35-million-capital-raise/) and [Series C announcement](https://hnry.co.nz/resources/news/hnry-raises-30-mil-to-accelerate-growth/) | The February 2023 page says “last year,” supporting a provisional 2022 year. Update dates, announcement dates, currencies and investor vehicles need care. |
| Dawn Aerospace | Satellite propulsion and reusable spaceplane development | [2022 financing](https://www.dawnaerospace.com/latest-news/dawn-raises-20million): NZ$20m; [2026 Series B](https://www.dawnaerospace.com/latest-news/dawn-aerospace-closes-us25-million-series-b): US$25m | Headers, indexed dates and body datelines differ. Future flight targets are not achieved milestones. |
| Zincovery / Zethos | Industrial technology for zinc recycling | [NZGCP case study](https://www.nzgcp.co.nz/portfolio/case-study/zincovery/) lists an August 2024 investment; [UC profile](https://www.canterbury.ac.nz/about-uc/why-uc/our-alumni/young-alumni/jonathan-ring) links the names | Name continuity is supported; exact rename date and legal-entity relationships remain open. Other co-investors listed on the case study are not all assigned the August date. |
| Trade Me | NZ online marketplace | [Company retrospective](https://secure.trademe.co.nz/c/community/article/our-story): 2000 success fees, 2006 Fairfax sale, 2011 listing, 2019 delisting | Founded before 2000, but has relevant later events. Internal Property launch dates conflict. No Movac relationship accepted from inaccessible reports. |
| GreenButton | Cloud tools for compute-intensive applications | [Microsoft NZ announcement](https://news.microsoft.com/en-nz/2014/05/02/microsoftazurestreng/), 2 May 2014 | [Microsoft’s register](https://www.microsoft.com/en-us/investor/acquisition-history) lists a 1 May press release. Legal completion day and price are not established. |

Company and investor reports establish what those parties reported. Medical efficacy, operating performance, investment returns and success are not independently established by this batch.

## Findings that affect the eventual application

**Names need their own history.** UC’s 18 February 2026 profile identifies Zethos as formerly Zincovery. The old company domain also redirects to Zethos, whose footer names Zincovery Process Technologies Limited. These support a name link, but do not resolve every legal entity or transaction. The [Booster announcement on NZX](https://www.nzx.com/announcements/440756) describes a proposed investment in a named entity; that transaction is not imported as a completed brand-level event.

**Dates need both precision and meaning.** February 2022, calendar year 2022 and an announcement on a particular day are different kinds of evidence. Hnry’s 2023 retrospective and Formus’s June article show why publication year cannot substitute for financing year. A later page cannot automatically be used as information that was available to an analyst at an earlier comparison date.

**Money needs scope as well as currency.** Amounts remain in source currency. No currency conversions or cross-currency totals were calculated. Locale variants, source-reported currency equivalents and combined financing announcements must not create extra rounds. A round total is not an individual investor’s cheque, valuation or investment return.

**Investor names need source-specific relationships.** An undated current portfolio listing does not establish a first investment date. Hnry’s 2019 reference to Ice Angels members is preserved separately from later Icehouse Ventures references. NZGCP’s direct investment programmes and its exposure through other funds also need distinct relationships.

## Coverage of the five requested investor sources

| Source | What was inspected | Remaining research |
|---|---|---|
| [NZGCP](https://www.nzgcp.co.nz/portfolio) | Portfolio snapshot, Aspire / legacy VIF and status controls; Zincovery case study | Enumerate named companies and historical annual-report cohorts; distinguish direct and fund-of-funds exposure. |
| [Icehouse Ventures](https://www.icehouseventures.co.nz/portfolio) | Featured names and portfolio links | Build a deduplicated list, including older/exited ventures; resolve network and investment vehicle names. |
| [Blackbird](https://www.blackbird.vc/portfolio) | Sector, stage and investment-year controls | Enumerate companies and verify each NZ connection; the global portfolio is not automatically an NZ cohort. |
| [GD1](https://gd1.vc/portfolio) | Directory, named homepage examples and Alimetry investment note | Recover the full list and reconcile company identities and dates against investment notes. |
| [Movac](https://movac.co.nz/investment-portfolio/) | Portfolio discovery and [fund history](https://movac.co.nz/funds/) | Research fund-specific company records and older outcomes. Fund vintage is not company investment year. |

No portfolio has been fully enumerated. Dynamic page extraction was incomplete in several directories. Headline portfolio counts are not treated as verified dataset counts. Two MBIE investor-guide PDFs returned 403; their search snippets remain discovery leads, not accepted claim sources.

## Working research structure for the Codex handover

Each venture should eventually have an identity record, a sourced NZ connection, dated observations, a timeline of events, source-specific investor relationships and explicit gaps. Product, customer, business model, commercialisation path and evidence maturity should inform comparison; funding size alone should not determine similarity.

The draft pack separates:

1. **Candidate identities:** research IDs, reported names/domains, proposed aliases and proposed existing-record links. No automatic merges or overwrites.
2. **Sources:** URL, issuer, publisher, publication/update dates where available, retrieval date, locator and access limitations.
3. **Observations and events:** claim, subject, source, date precision, date basis, monetary scope and review state.
4. **Relationships:** reported investor name and role; a dated round link only where supported. Legal investment vehicles may remain unknown.
5. **Analyst proposals and unresolved cases:** kept apart from sourced claims and accepted comparison features.

Unknown current operating status, funding stage, registration number and legal name remain empty. A historical Series B event does not establish a company’s current stage. No personal contact details were collected.

For the eventual new-venture entry flow, the same structure should allow a user to supply a name, NZ connection, product/customer description and supporting sources, then compare available evidence while exposing missing fields. This is a proposed implementation direction; it was not built during this research phase.

## Next research batch

The next useful milestone is a deduplicated 30–50-company discovery inventory across the five source families, followed by deeper evidence collection. That milestone should deliberately include older and exited companies rather than only currently promoted ventures.

Priorities are:

1. Investigate 2000–2010 activity and historical fund records. This pilot is weighted towards recent financing and cannot support conclusions about earlier decades.
2. Reconcile existing UoA identities and the Zincovery/Zethos name history; resolve high-impact currency and financing-scope gaps.
3. Add documented closures, acquisitions and listings where sources support them. Absence from a current portfolio page is not evidence of closure.
4. Define comparison fields and missing-data rules against real candidate evidence before expanding to hundreds of companies.
5. Prepare the final implementation handover only after the researched cohort, inclusion rules and unresolved limits are explicit. Proposed exports and visualisations must identify their population and evidence cutoff.

The immediate completed deliverable is this ten-venture source-linked research pilot. Comprehensive historical coverage, accepted identity merges, comparison scoring, new visualisations and application imports remain future work.
