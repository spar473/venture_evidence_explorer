# Implementation note — research interchange 0.2

18 November 2026. **Ready for modelling/implementation review; not a compatible application import.** This research task performed no app/database writes, migrations, record imports, retrieval changes or publication. Concurrent application/database changes were observed and preserved; byte-for-byte preservation of the app overall cannot be claimed.

## Contract actually inspected

Read-only inspection covered the following files in `/Users/kevinnn.park/Documents/venture_evidence_explorer`:

- `scripts/bootstrap.py` and, after the concurrent refactor, `backend/ingestion.py`: strict input models, `validate`, `adapt_records`, `store_extensions`, `insert_immutable` and `load_seed`.
- `schema/schema.sql`: sources, ventures, observations, awards, connections, annotations and import tables.
- `schema/migrations/001_analytics.sql`: analytical views and review-event structure.
- `schema/migrations/002_immutable_evidence.sql`: immutability and subject guards.
- `schema/migrations/003_historical_evidence.sql`: newly present additive date/value/availability/correction structures.
- The existing seed IDs for RosterLab and QuickMas and current B0 field eligibility in `backend/retrieval.py`.

The app was actively changing during this task. An initial AST-only probe could not find the relocated definitions, so the new importer was re-read. It now accepts integer input schema versions **1 and 2**, with historical date intervals and typed observation values. The research packet's `format_version: "0.2"` is neither contract.

A validation-only probe called the current app's `validate` function with bytecode writes disabled and SQLite connections replaced by a fail-fast guard. It rejected the packet as expected. No `load_seed`, migration, storage function or database access was invoked by that probe. The validation record hashes the probed module; further concurrent changes need rechecking before implementation.

## Material gaps

| Existing application contract | Research need / proposed change |
|---|---|
| Six seed arrays: sources, ventures, observations, awards, connections, annotations | Explicit adapter and reviewed mappings for subjects/parties/events/reports/unknowns/readiness/cases; never point bootstrap at the new JSON |
| Input version 2 already supports nullable publication with `HistoricalDate` intervals, availability evidence and additive storage | Reuse and reconcile these facilities; map research date values to calendar bounds without invented dates. Explicit missing reasons, update/access/version metadata and passage responsibility still need mapping. |
| Observations retain `assertion_type == publisher_report`, a controlled legacy review enum, and optional historical/financial/event values | Retain existing typed values while separating assertion nature, speaker relationship, review lineage, scope and customer/payment relationships. Do not discard either model's semantics. |
| Award model plus per-observation `event_value`; no separate event identity/report graph | Add or adapt event identity/report associations without duplicating existing observation values or recasting all events as awards |
| University connections reference a same-subject `uoa_connection` observation | Separate target/user/customer/payer/procurement and investor relationships, each with their own evidence; do not overload university connections |
| Proposed annotation evidence is same-subject only | This packet has a two-subject proposed interpretation. It needs a multi-subject evidence bridge or an explicitly limited projection, not a silent flattening. |
| Review events target exactly one observation or annotation, with accepted/rejected/needs-review decision | Separate extraction state from real acceptance decisions; decide how identities, events, reports and readiness are reviewed. Preserve existing append-only lineage. |
| Exact declared columns and immutable full-row equality checks | New numbered migration/adapter needed; extra fields cannot be ignored without explicit loss accounting. Preserve prior observations and migrations. |
| B0 uses sourced `product_description` and `uoa_connection` | New research fields do not automatically become B0 inputs. Review the projection, acceptance policy, corpus version and evaluation before changing retrieval. |
| Existing historical-date/value/availability/correction relations and evolving evidence-policy code | Extend the current design, rather than creating parallel competing date stores. Recheck canonical date/age queries and missingness before adapters or analytical projections. |

The app's broader concurrent feature work was not re-verified in this research task. This packet itself adds no write API, review UI or expanded comparison corpus. Current source inspection still shows B0 eligibility on `product_description` and `uoa_connection`; this is not a fresh end-to-end validation of the changing app.

## Candidate implementation direction, subject to review

Prefer additive research entities and immutable evidence references linked to accepted existing venture IDs, with a deliberate projection into application views. Reuse the app's newly present `evidence_dates`, `observation_values`, `source_availability` and `observation_relations` where their semantics fit. Keep one configured application source of truth. The current JSON is a review/interchange artifact, not a second production store or permission to import.

An adapter should validate the packet, resolve or quarantine identity links, retain source/report versions, refuse conflicting immutable IDs, and keep unresolved event candidates out of aggregates. Import writes should be transactional. Preserve original migrations and add new ones; their existing checksums must not be rewritten.

Expose attributed statements, offered versus actual relationships, date precision, unknown reasons and question-specific supported/withheld conclusions in the UI. A named adopter and a source-checked record must not become a paid customer or an independently accepted fact. Do not show two unresolved financing candidates as two raised rounds.

## Remaining decisions

1. Accept or leave proposed links to `v_rosterlab` / `v_quickmas`; legal identities remain unverified.
2. Reconcile the two RosterLab financing event candidates, including currency, settlement date and exact legal vehicle. Do not sum before resolution.
3. Define who may accept which records, whether owner acceptance differs from independent review, and how disputes/history are retained.
4. Agree event-state history, cancellation/target-to-occurrence links, source capture/versioning and historical availability rules before backtesting.
5. Extend the deliberately narrow field/event enums for other dossier types, including alternatives, laboratory/clinical studies and completed integrations, with versioned definitions.
6. Decide the reviewed projection into retrieval, and use fresh comparison tasks/real judgments before making relevance or usefulness claims.

The current examples support limited descriptive comparisons and offering summaries while withholding procurement, paid-sale, regulatory and elapsed-time conclusions where evidence is missing. They are ready to review the data model and adapter requirements. Direct ingestion and a production comparison release remain premature.
