# Supporting context for the master handover

Start with ../Code_Agent_Handover_v2_2026-11-18.md. New_Chat_Prompt.txt is the context-loading prompt. Snapshot_Verification.json and Source_Manifest.json identify the current tested source. checks/ contains the new compilation verification logs.

references/ preserves the starter implementation handover and project specification; the original Downloads Code_Agent_Handover.md is unavailable and is not claimed to be recovered verbatim. research-history/ contains earlier research packs/frameworks, not accepted corpus data. historical-planning/ and historical-review/ retain prior requests/status/findings; the three old review defects are now fixed. Do not execute their old fix/import prompts merely because they are present. engineering-records/ carries selected historical reports, not every temporary log or backup. The current application/engineering_completion.md in the ZIP describes the latest implementation.

The application snapshot is a reference: do not extract over a newer checkout. Live DBs, virtual environments, node_modules, compiled frontend, caches and private credentials are omitted. Rebuild disposable data from preserved seed plus explicit research/discovery imports; do not assume this recreates old physical database or replay hashes.
