# Venture Evidence Explorer — first local release

Implemented in `/Users/kevinnn.park/Documents/venture_evidence_explorer`. The app is running at http://127.0.0.1:8000, bound to loopback only. No repository was created, no deployment/publication occurred and no one was contacted. MCDA Studio was untouched.

## What works

FastAPI + React/TypeScript over SQLite: venture browsing, names/aliases/product search, actual award programme/year and connection filters, reset/loading/empty/error states; source-linked detail views with publication/retrieval/event/effective-date distinctions and explicit unknowns; separate proposed annotations; explainable, deterministic comparison search with source passages, vocabulary differences, unavailable evidence, five suggested questions and conservative abstention; source-age/coverage, overlapping relationship and programme-year analytical views/CSV downloads.

Selecting a subject or naming it excludes self-matches. Product and commercialisation-origin search modes use sourced observations only. Stage/milestone mode explains missing eligible evidence. No proposed annotations or awards enter retrieval weights. Import conflict rollback, duplicate-ID checks, source-subject constraints, strict column validation, immutable evidence, checksummed migrations and atomic per-file CSV replacement are implemented.

## Run again

Dependencies and the frontend build are already installed in the supplied project:

```sh
cd /Users/kevinnn.park/Documents/venture_evidence_explorer
.venv/bin/python scripts/serve.py
```

Open http://127.0.0.1:8000. If the running copy already occupies port 8000, use `--port 8001` or stop that server first.

For a clean dependency setup:

```sh
cd /Users/kevinnn.park/Documents/venture_evidence_explorer
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
.venv/bin/python scripts/bootstrap.py
.venv/bin/python scripts/verify.py
cd frontend
npm ci --ignore-scripts
npm run build
cd ..
.venv/bin/python scripts/serve.py
```

Setup downloads packages; the built app needs no credentials or external services. Opening public-source links requires internet. The original standard-library bootstrap commands still work.

## Checks and limits

Baseline checks passed before implementation. In the installed project, bootstrap/integrity verification, 13 backend tests, TypeScript/production build and 7 Chrome end-to-end checks pass. Browser checks cover actual browse/filter/evidence/comparison flows, downloads, error recovery, loading, stale query responses and narrow/desktop rendering. The release's 44 source/document/input digests match its manifest. Seed and evaluation artifacts are preserved, and the database contains no invented review events.

Initial dependency/network and browser sandbox restrictions were resolved with authorised execution. An invalid synthetic test date and two browser selectors were corrected; no final test failures remain. Non-failing third-party deprecation warnings remain.

Source-link/subject mapping was verified for all supplied observations and awards. Live source page contents/availability and the factual truth of publisher reports were not independently re-audited. Other browsers/platforms, PostgreSQL and Power BI desktop were not tested.

Ten ventures/projects, seven sources, 20 observations, seven awards, ten connections and 50 proposals remain the selected historical sample. Legal identity, current operating status, funding and outcomes stay unknown. These are publisher reports, not current profiles. No success rate, investment return, programme effectiveness or retrieval-quality metric is claimed.

The six development queries were executed without labels: q02 and q05 return lexical candidates, while q01/q03/q04 abstain under the threshold and q06 abstains for absent milestone evidence. This records behaviour, not relevance quality. Full outputs are in `development_search_run.json`. The reviewer template remains blank.

## Next three improvements

1. Owner identity review, dated source captures and defined award-cohort expansion, retaining unresolved identities.
2. Real independent relevance judgments and voluntary usability measurement; then evaluate reviewed structured or semantic retrieval against B0.
3. A genuine Power BI report from curated views and a reconciled PostgreSQL migration when justified.

Semantic/LLM retrieval, a review UI, accepted structured features, a real `.pbix`, current-status verification and MCDA integration are planned extensions, not shipped functionality.

The project README contains the demo path and method specification. `docs/architecture.md` contains the data-flow diagram and migration path; `docs/decisions.md` records design tradeoffs; `VALIDATION.md` distinguishes engineering checks from factual or usefulness validation. Original starter files replaced during implementation were backed up locally, and the application was applied only after checking the original 30 files for concurrent changes.
