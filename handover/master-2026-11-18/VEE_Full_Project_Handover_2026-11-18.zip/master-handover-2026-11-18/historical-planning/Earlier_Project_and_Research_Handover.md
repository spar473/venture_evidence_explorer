# Venture Evidence Explorer — project and research handover for brainstorm verification

Prepared for Kevin Park on 17 November 2026, Pacific/Auckland.

**Current position:** a first local application has been implemented and visually refined. A separate historical NZ venture research programme has begun, reaching 274 name-normalised research entries across 27 investor and commercialisation source families. The expanded research has **not** been imported into the application. The final historical venture list, legal identity reconciliation and relevance evaluation remain unfinished.

**Purpose of this document:** give another brainstorm chat enough context to challenge the project direction, evidence quality, research scope and proposed next implementation. This is a status summary and review brief, not an instruction to execute the original handover or begin coding.

## 1. Why this project exists

Kevin is finishing Engineering Science at the University of Auckland, has AI/data research experience and experience leading Velocity. The project is intended to demonstrate credible work to venture-capital teams and data analyst/data engineering recruiters while helping student founders and the university startup community.

The central product question is:

> When someone encounters a startup, which ventures and commercialisation precedents should they investigate, what differences matter, and what evidence supports the comparison?

The initial users are an early-stage analyst preparing for a company meeting and a founder investigating comparable commercialisation challenges. The tool supports investigation; investment quality, founder quality and predicted returns have not been modelled or validated.

The project is separate from MCDA Studio. That application and its ranking engine have not been modified or copied into this project.

## 2. How the scope developed

| Phase | User direction | Work completed / present position |
|---|---|---|
| Original implementation | Read the code-agent handover and starter material; inspect the workspace; run bootstrap/integrity checks; implement and verify a usable local release. | Baseline checks, application, reproducible ingestion, analytical exports and release documentation completed. |
| Design refinement | Improve the overall presentation because the interface looked too generically AI-generated; use supplied design references. | Replaced promotional framing and repeated card surfaces with a compact research directory, evidence drawer and restrained visual system. |
| Broader product discussion | Clear per-venture visualisation; comparison with hundreds of NZ ventures across years from 2000 onwards; ability to insert a new venture into comparison. | These are accepted product ambitions. Full historical coverage, new-venture persistence and richer visualisations are not shipped. |
| Research first | Keep the UoA starting cohort, research company histories and investor portfolios, then hand the researched material to Codex for further implementation. | Application changes paused while separate public-source research proceeds. |
| Broader investor coverage | The five named investors were examples, not a restriction. | Expanded to 27 investor/commercialisation source families, including 22 beyond the original five. |
| This review | Summarise the whole project and research for a brainstorm chat to verify. | This document consolidates the current position and identifies the decisions still needed. |

The attached `Code_Agent_Handover.md` and starter specifications supplied requirements and background for the authorised implementation. The pasted design document supplied reference material; its package-installation examples and suggested agent instructions were not blanket authorisation to install tools or change permissions. The user's later decision to research before further implementation governs the current phase.

## 3. What the local application currently does

| Capability | Implemented behaviour | Boundary |
|---|---|---|
| Browse ventures | Search names, aliases and sourced product wording; filter by award programme, award year and UoA relationship type; reset filters. | Searches the original ten-record application sample. |
| Inspect evidence | Show descriptions, recorded awards, university relationships, source links, publishers, dates, passage locators and review states. | Reports historical source statements; it does not establish current company status or independently validate every publisher claim. |
| Separate proposals | Display proposed analyst annotations separately from sourced observations. | Proposals do not become accepted facts or retrieval features. |
| Compare a known venture | Select a subject or identify it by name/alias; exclude self-matches. | Identity ambiguity causes abstention rather than an automatic merge. |
| Compare a description | Product/customer or commercialisation-origin wording search, returning zero to three candidates with matching terms, source passages, vocabulary differences and evidence gaps. | This is deterministic lexical retrieval, not validated semantic reasoning. |
| Handle insufficient evidence | Empty/irrelevant queries and stage/milestone mode explain why results are unavailable. | There is no eligible verified commercial-milestone dataset in the app. |
| Draft questions | Show five generic suggested diligence questions in a deterministic/template brief. | These are suggestions, not findings about company weaknesses. |
| Export analyses | SQL views and CSV downloads for programme recognition by year, overlapping UoA connection types, source publication age and evidence coverage; separate source/proposal exports. | Power BI-ready data is delivered; a genuine Power BI report is not. |
| Handle UI states | Loading, empty and recoverable error states; stale-response invalidation. | Other browsers/platforms and formal accessibility conformance remain unverified. |

**New-venture entry distinction:** the user can already enter a free-text venture description to search. There is no implemented interface/API for saving a new venture, its sources, timeline and investor relationships into the database. That fuller insertion workflow remains future implementation.

### Retrieval baseline

The implemented method is `b0-token-overlap-1.0`:

- Lowercase alphanumeric tokens, fixed stopwords and an inspectable morphology map; tokens shorter than three characters excluded.
- Product/customer mode uses sourced product descriptions. Commercialisation mode additionally uses sourced UoA-origin/connection wording.
- Each token counts once per venture, avoiding extra weight from repeated observations.
- `IDF(t) = 1 + ln((N + 1) / (df(t) + 1))`.
- Score is matched query-token IDF divided by total query-token IDF.
- Require at least two informative matching tokens and at least 15% query-token coverage; return at most three results, with stable-ID tie-breaking.
- Awards, prestige, founder pedigree, press volume and proposed annotations are excluded from retrieval weights.

Scores are ranking scores, not relevance probabilities, confidence or investment scores. Reported wording differences do not establish missing product features or company weaknesses. Expanding the corpus can change scores and rankings, so the method version alone is insufficient for reproducibility without a corpus version.

## 4. Architecture and data engineering

The application uses Python/FastAPI, React/TypeScript and SQLite. FastAPI serves the built frontend and API on loopback. SQLite is the sole application/analytical store; CSVs are generated outputs, not a second editable master dataset.

```text
Public-source seed -> validation -> transactional import -> SQLite
                                                     |-> read-only API -> React UI
                                                     |-> B0 retrieval -> comparison explanations
                                                     |-> analytical SQL views -> CSV exports

Separate research JSON/Markdown packs -> reconciliation/review still required -> future import adapter
```

Implemented protections include stable identifiers, parameterised SQL, exact imported-column validation, duplicate checks, foreign-key/subject/date checks, immutable evidence, checksummed migrations, conflict refusal and rollback, and an append-only review-event structure. Runtime API operations do not write venture data. The comparison POST endpoint performs a read-only computation.

Programme/year filters apply to the same actual award row. Relationship categories may overlap; the sample's selection bucket is not exhaustive programme membership.

Imported data writes roll back together. A refused import may leave an empty schema upgrade because migrations precede the data import transaction. CSV replacement is atomic per file, not across the entire export bundle.

PostgreSQL migration is documented but has not been exercised. Review-event schema exists; a review UI and accepted-feature curation pipeline do not. No accepted review events have been invented.

## 5. The original application dataset

The first cohort consists of selected Velocity $100K award recipients, Ideas Challenge award recipients and ventures/projects with documented UoA connections. It is not a complete award cohort or university ecosystem census.

The ten application identities are AgriPhage, Alimetry, AtlasOR, BioSleeve, Formus Labs, IVF support tool, Pollsport, QuickMas, RosterLab and Deployable Space Optics.

| Application object | Current count |
|---|---:|
| Venture/project identities | 10 |
| Public University source records | 7 |
| Source observations | 20 |
| Award records | 7 |
| University connection records | 10 |
| Proposed annotations | 50 |
| Annotation-to-evidence links | 50 |
| Review events | 0 |
| Applied numbered migrations | 2 |

All ten retain unknown legal name, registration ID, current operating status and current funding stage. Project names are not automatically incorporated companies. No public update is not evidence of inactivity or failure. Awards are not commercial success or investment-return labels.

Formus's source discusses a founder's earlier IMeasureU award. That award was not transferred to Formus. Source publication, retrieval and event dates remain distinct; a 2026 retrieval date does not prove information was available at an earlier backtesting cutoff.

## 6. Design work completed

The visual direction is a compact, readable research workspace:

- Aligned venture rows and a compact filter toolbar replace an oversized introductory area and repeated card grid.
- A native modal evidence drawer preserves directory context, supports Escape, contains keyboard focus and returns focus to the opening control.
- Neutral grey/white surfaces, dark text, one controlled blue accent and a separate pale treatment for proposals.
- Local system typography, restrained spacing/borders and limited shadows. No external fonts or new UI component libraries were required.
- Comparison and export screens use readable labels and a consistent hierarchy.
- Narrow layouts reflow records; skip navigation, visible focus, labelled controls and reduced-motion support were included.

The supplied references included Anthropic frontend-design guidance, Vercel Web Interface Guidelines, UI/UX Pro Max, Primer and shadcn/ui. They informed design decisions; Primer and shadcn/ui were not installed as dependencies. The result has been visually reviewed, but no formal accessibility certification or measured usability improvement is claimed.

## 7. Verification completed — and its limits

| Stage | Evidence recorded | What can be concluded |
|---|---|---|
| Before implementation | Existing bootstrap and integrity checks passed. | The supplied baseline was runnable in the inspected environment. |
| Initial local release | Bootstrap/verify, 13 backend behavioural tests, TypeScript/production build and seven Chrome end-to-end checks passed. | The recorded release behaviours were exercised; this is not factual or relevance validation. |
| Interface redesign | TypeScript/build passed; connected-browser checks at desktop and 390px width covered filters, evidence, unknowns, drawer keyboard behaviour, comparisons, abstention, exports and error handling. | The redesigned flows were manually checked in that environment. |
| Updated automated UI suite | Eight browser test definitions now exist, including drawer Escape/focus regression. | The updated eight-test suite was not rerun after the redesign. The earlier seven-test pass must not be presented as a pass for the updated suite. |
| Research packs | Identifiers/references, date precision, expected unknowns and structural counts checked. | Data structure passes; issuer truth, legal identities and population completeness remain unvalidated. |
| This summary preparation | Read-only SQLite integrity check returned `ok`; zero foreign-key violations; counts above confirmed; all 45 files in the current release manifest matched; built frontend present. | A fresh local consistency snapshot, not a fresh end-to-end app run. |

Backend checks address repeat ingestion, full-row equality, rollback on conflicting imports, schema/column refusal, identity and subject constraints, overlapping filters, missing/error cases, deterministic ranking, self-exclusion, proposal isolation, exports and blank evaluation labels. Synthetic fixtures remain in temporary test databases.

Non-failing third-party deprecation warnings were recorded. Only the local macOS Chrome environment was exercised in the original automated browser run. Current live source availability and the factual truth of all original seed reports were not independently re-audited during app verification.

Six evaluation queries remain development examples; the judgment template remains blank. No nDCG, precision, reviewer agreement, time savings, usefulness improvement, success rate, programme effectiveness or investment return has been measured or claimed. The original specification's identity-review, independently judged search and voluntary-user gates are not fully satisfied merely because the software checks passed.

## 8. Research direction and inclusion rules

The user wants clear visualisation of each venture, comparisons across hundreds of NZ ventures and years from 2000 onwards, and eventual insertion of a new venture into that comparison workflow.

The working research approach is to retain UoA as a labelled cohort within a broader NZ evidence collection. Eligibility should be based on documented NZ origin or substantive historical NZ headquarters/operations, with the exact rule still to be agreed. NZ-founded companies that later moved overseas can remain relevant. A global firm's entire portfolio is not automatically an NZ cohort. A company founded before 2000 may qualify through relevant post-2000 events.

Portfolio pages identify candidates. Dated company, investor, university, exchange, acquirer and government records are needed to reconstruct history. Discovery, source extraction, identity acceptance and analytical use are separate stages.

### Research pilot: ten ventures

The first research batch covers Alimetry, Formus Labs, Halter, Tracksuit, Vessev, Hnry, Dawn Aerospace, Zincovery/Zethos, Trade Me and GreenButton. Alimetry and Formus have proposed links to existing application IDs; no merge or overwrite occurred.

| Pilot object | Count |
|---|---:|
| Candidate ventures | 10 |
| Source records | 29 |
| Observations | 28 |
| Event records | 21 |
| Investor relationship claims | 41 |
| Proposed investigation angles | 10 |
| Unresolved cases | 13 |

These are research-object counts. Events include non-financing reports, and source counts include directory/discovery pages. They are not counts of independently confirmed funding rounds or complete investor portfolios.

### Expanded discovery inventory

| Expanded inventory object | Count / state |
|---|---:|
| Name-normalised research entries | 274 |
| Original research-pilot entries included within 274 | 10 |
| Additional targeted historical outcome checks | 4 |
| Portfolio-discovery-only entries | 260 |
| Investor/commercialisation source families | 27 |
| Additional families beyond the original five | 22 |
| Listing/provenance records | 365 |
| Source records in expanded pack | 42 |
| Accepted, independently deduplicated NZ population count | Unknown |

The 274 includes the ten research-pilot entries and is **not additive** to that pilot. It is also not a reconciled union with the application's original ten identities. Research packs share source records; their source counts must not be added as though independent.

The 365 records include pilot provenance references and portfolio mentions. They do not establish 365 investments or same-round co-investments. Case/punctuation/spacing normalisation supports provisional research grouping; legal identity deduplication is unfinished. Several possible aliases intentionally remain separate, so 274 can shrink after review. New to the research inventory does not necessarily mean new to the existing application.

## 9. Investor and commercialisation coverage

These are research categories, not legal classifications or a claim that all 27 are currently active VC firms. Portfolio extraction is incomplete for several sources.

| Category | Source families included |
|---|---|
| Originally named | NZGCP; Icehouse Ventures; Blackbird; GD1; Movac |
| Additional technology, deep-tech and growth investors | Punakaiki Fund; Pacific Channel; Outset Ventures; Nuance Connected Capital; WNT Ventures; Matū; Quidnet Ventures; NZVC; Altered Capital |
| Sector-focused investors/builders | Sprout Agritech; Bridgewest Ventures; Motion Capital; Climate Venture Capital Fund; Cure Kids Ventures; Brandon Capital |
| Angel networks | Enterprise Angels; Angel HQ |
| University/research commercialisation and investment | UniServices / UoA Inventors' Fund; Massey Ventures; Wellington UniVentures; Booster Innovation Fund |
| Historical fund requiring manager-history research | Hillfarrance |

Important distinctions:

- NZGCP's direct programmes and fund-of-funds exposure are different relationships.
- A fund, its manager, an angel network and an individual member investment must not become duplicate independent cheque writers. Climate Venture Capital Fund identifies 2040 Ventures as manager.
- University directories can mix ventures, technologies, licences, projects and people. Not every card is a company or equity investment.
- Outset's investment portfolio and its resident/alumni community are different relationship sets.
- Quidnet and Cure Kids portfolio extraction encountered unreadable/timeout results; their whole company lists were not invented from snippets.
- Enterprise Angels, Angel HQ and Altered Capital had incomplete company extraction. Missing names are not evidence of absence.
- NZGCP's FY25 report records a Hillfarrance management change. Historical and current manager/vehicle identities require explicit handling.
- Other regional angel groups, historical/defunct funds, offshore investors in NZ companies and underrepresented regions remain expansion priorities. The directory is broader, not exhaustive.

## 10. Research findings that matter for data design

| Case | Finding and consequence | Inspectable evidence |
|---|---|---|
| Zincovery / Zethos | UC explicitly links the names. Preserve the supported name history; exact rename date and all legal-entity/transaction relationships remain unresolved. | [UC profile](https://www.canterbury.ac.nz/about-uc/why-uc/our-alumni/young-alumni/jonathan-ring) |
| Aplenty / Hot Lime Labs | Booster explicitly reports the former name. Grouping for research must not silently backdate every brand/legal event. | [Booster portfolio, Aplenty entry](https://www.booster.co.nz/products-services/booster-investments/booster-innovation-fund/investments) |
| Formus | June 2022 publication describes a US$5m financing in February. Publication month is not financing month; IMeasureU events belong to a different subject. | [UoA article](https://www.auckland.ac.nz/en/news/2022/06/29/formuslabs-raises-towards-ai-powered-orthopaedic-surgery.html) |
| Alimetry | Company US$18m/A2 and GD1 $30m/Series A Expansion reports require currency/scope reconciliation; do not create two confirmed rounds. | [Company](https://www.alimetry.com/press/alimetry-raises-an-oversubscribed-us-18m), [GD1](https://gd1.vc/notes/alimetry-investment-notes) |
| Tracksuit | Regional currency presentations of one Series A must be deduplicated; selected Series B currency remains unresolved. | [AU announcement](https://www.gotracksuit.com/au/blog/posts/raise-announcement-series-a), [UK announcement](https://www.gotracksuit.com/uk/blog/posts/raise-announcement-series-a) |
| Hnry | A February 2023 page says the Series B occurred in the preceding year. The 2022 interpretation is provisional; last-updated date is not original publication or legal closing date. | [Company report](https://hnry.co.nz/resources/news/hnry-secures-35-million-capital-raise/) |
| Vessev | $19m announcement combines Series A and follow-on financing. A named customer does not itself establish paid revenue or completed operation. | [Company-issued release](https://www.prnewswire.com/news-releases/vessev-enters-us-market-with-19-million-series-a-names-first-us-customer-and-launches-multi-city-us-showcase-302856533.html) |
| Status extraction | Pacific Channel's extracted text repeats ceased/exited labels. Those labels were not assigned to every company. | [Portfolio](https://pacificchannel.com/portfolio) |
| Parent/product dates | Autohive's card displays an earlier investment date while describing a later launch by Raygun. Resolve the subject before treating it as a venture investment event. | [Punakaiki portfolio](https://punakaikifund.co.nz/portfolio/) |

Other preserved gaps include source-header/body date differences for Dawn Aerospace, regional announcement dates for GreenButton, internal chronology differences in Trade Me's retrospective and source-specific currency/vehicle ambiguity. Two MBIE investor-guide PDFs returned 403; their indexed snippets remain discovery leads rather than accepted evidence.

### Four targeted historical outcome checks

| Candidate | Reported outcome | Qualification / source |
|---|---|---|
| Vend | Lightspeed reports acquiring all outstanding shares on 16 April 2021. | Acquirer's dated financial filing is preferred for that event while retaining the investor-directory 2020 conflict. [Filing, notes 3–4](https://www.sec.gov/Archives/edgar/data/1823306/000182330621000071/financialstatementsfy22q1.htm) |
| Timely | EverCommerce announced completed acquisition on 8 July 2021. | Do not conflate announcement, contract, investor economic exit and legal close without evidence. [Release](https://www.prnewswire.com/news-releases/evercommerce-completes-acquisition-of-timely-leading-business-management-software-for-beauty-industries-301327691.html) |
| Moxion | Autodesk announced acquisition on 19 January 2022. | Source gives a fiscal closing quarter; exact closing day remains unestablished. [Release](https://investors.autodesk.com/index.php/news-releases/news-release-details/autodesk-acquires-moxion-cloud-solution-digital-dailies) |
| HaloIPT | Qualcomm announced technology/asset acquisition and team transfer on 7 November 2011, identifying UoA research origins. | Asset/team acquisition is not automatically acquisition of all company shares. [Release](https://www.qualcomm.com/news/releases/2011/11/qualcomm-acquires-haloipt-team-and-its-wireless-electric-vehicle-charging) |

These are source checks, not complete profiles or independent legal transaction verification. Acquisition consideration and investor returns were not analysed in this pass.

## 11. Research data rules established so far

1. Keep candidate identity, brand/name history, legal entity and investment vehicle separate. No automatic application merges.
2. Keep publication, update, retrieval, event, effective and announcement dates distinct. Preserve year/month precision and the basis for inferred relative dates.
3. Preserve source currency, raw amount, qualifier and scope. No FX conversion or cross-currency total has been calculated. Equivalents are not additional rounds; round totals are not individual cheques or valuations.
4. Separate current portfolio mentions from dated investment events. Two investors listing a company does not prove participation in the same round.
5. Attribute issuer releases to their issuer even when hosted by PR Newswire. Distribution is not independent corroboration.
6. Keep unknowns null. Historical stage labels and portfolio membership do not establish current funding stage or operation.
7. Keep analyst investigation angles proposed. They are not accepted features, relevance judgments or company facts.
8. Preserve source conflicts and access gaps. No full historical page archive or proof of past availability has been created.
9. Treat every count as a count of its stated unit and selected population. Do not derive success rates or market coverage from this collection.

The research formats are `research-pilot-0.1` and `expanded-discovery-0.1`. Both are explicitly marked as research in progress and not directly importable. They require reconciliation with the application's schema and identities before implementation.

## 12. Completed work versus proposed extensions

| Completed / recorded | Still proposed or unfinished |
|---|---|
| Local FastAPI/React/SQLite release and restrained interface refinement | Rich per-venture timelines/charts and a broader longitudinal comparison table |
| Source inspection, filters, lexical comparisons and CSV analytics | Saving a new venture with sources, evidence review and persistent comparison records |
| Ten-item UoA application sample | Importing the expanded research and reconciling all existing identities |
| Ten-venture research pilot, broader discovery inventory and four outcome checks | An accepted, deduplicated final NZ venture list covering 2000 onwards |
| Source-linked research records and explicit open cases | Complete investor portfolios, older/closed-company coverage and dated source captures |
| Append-only review schema and blank evaluation templates | Review UI, real independent judgments, accepted structured features and usefulness measurement |
| Deterministic B0 retrieval with abstention | Evaluated structured, semantic or hybrid retrieval; LLM-generated briefs |
| Power BI-ready exports and documented PostgreSQL path | Genuine `.pbix` report; exercised PostgreSQL migration |
| Separate MCDA Studio boundary | A reviewed adapter matching MCDA Studio's actual interchange contract |

The current research discovery is weighted towards readable, currently visible portfolios. The 2000–2010 period, defunct funds, exits/closures and companies missing from marketing pages need deliberate follow-up. No venture growth or outcome chart should imply complete annual coverage at this stage.

## 13. Proposed next sequence for review

These are proposed priorities for the brainstorm chat to challenge; they are not new implementation already performed.

1. **Agree inclusion and comparison definitions.** Define NZ eligibility, historical window, venture versus project/technology, and the primary comparison use case. Keep UoA/programme membership as cohort labels.
2. **Reconcile the discovery inventory.** Resolve likely aliases and parent/successor relationships; match existing application IDs; document exclusions and unresolved candidates.
3. **Deepen historical evidence.** Prioritise older and exited/closed cases, dated investor records and high-impact date/currency conflicts. Record coverage by source, period, sector and region without treating gaps as zero.
4. **Specify the next data contract and visual workflows.** Decide which evidence supports profile timelines, investor relationships, funding events, comparison features and new-venture entry. Avoid charts unsupported by comparable measures.
5. **Handover accepted research for local Codex implementation.** Build a validation/import adapter, preserve original observations, add reviewed fields and meaningful workflow tests, then rerun the updated browser suite.
6. **Evaluate before making usefulness claims.** Obtain real reviewer judgments, separate development/held-out tasks, retain disagreements and compare any new retrieval approach against B0 on a versioned corpus.

No paid API, account, hosted database or deployment is required for the current application. Future API/provider/budget/data-handling choices remain separate decisions.

## 14. Local operation and boundaries

Application location:

```text
/Users/kevinnn.park/Documents/venture_evidence_explorer
```

For the already-installed project:

```sh
cd /Users/kevinnn.park/Documents/venture_evidence_explorer
.venv/bin/python scripts/serve.py
```

Open `http://127.0.0.1:8000`; use `--port 8001` if needed. This summary does not assert a server is currently running. Package installation needs internet; the built app needs no credentials or external services. Opening public source links requires internet.

For later verification, the documented commands are bootstrap, verify, backend pytest, frontend build and Playwright. Bootstrap is an import/export operation; it was **not rerun to prepare this summary**. The fresh summary checks used a read-only database connection and file hashes.

Work remains local. No remote repository was created, nothing was pushed/deployed/published and no one was contacted. The app folder currently has no `.git` marker. Existing changes and source data were preserved. No private Velocity submissions, judging feedback, committee records or student contact details were used. Application code/data were not changed during the research or summary phases.

## 15. Evidence and artifact index

The paths below identify existing local records. Another chat will not gain access to the filesystem merely because this document includes a path. This summary is sufficient for a conceptual review; an independent record-level audit also needs the relevant JSON/data/code attachments.

| Artifact | Role |
|---|---|
| `outputs/Release_Handover.md` | Initial release scope, run commands and historical verification |
| App `README.md`, `VALIDATION.md`, `docs/architecture.md`, `docs/decisions.md`, `docs/design.md` | Current implementation/method, validation limits, architecture and design decisions |
| `outputs/design-review/Design_notes.md` and directory/evidence/mobile screenshots | Redesign evidence |
| `outputs/research/batch-01/Research_notes_01.md` | Ten-venture pilot narrative |
| `outputs/research/batch-01/Research_pack_01.json` | Pilot source, observation, event, relationship, proposal and issue records |
| `outputs/research/batch-01/Validation_record.json` | Pilot structural counts/checks |
| `outputs/research/expanded-discovery/Expanded_research_list.md` | Full 274-entry working list, depth labels and source links |
| `outputs/research/expanded-discovery/Discovery_pack.json` | Broader source directory, candidates, listings, name links, targeted events and open cases |
| `outputs/research/expanded-discovery/Validation_record.json` | Expanded inventory counts/checks |

The `outputs/` paths in this table are relative to:

```text
/Users/kevinnn.park/Documents/Codex/2026-11-17/read-code-agent-handover-md-and-3
```

The application artifacts are in the separate application directory above. The original starter manifest was retained for provenance; the current release manifest is `RELEASE_SHA256SUMS.txt`.

## 16. Copy-ready request for the brainstorm chat

> Please review this Venture Evidence Explorer handover critically before further implementation. Treat its claims as reported project status and use the cited sources or attached research packs when checking them. Distinguish user requirements, shipped functionality, historical test results, source reports, analyst proposals and unresolved cases. Do not assume that passing software tests establishes factual correctness or usefulness, or that 274 research entries means 274 accepted NZ companies.
>
> Assess: (1) whether the product scope and target user are coherent; (2) whether NZ eligibility, identity/name history and 2000-onwards coverage rules need refinement; (3) which missing data or sources would most change the comparison design; (4) whether the current method handles missingness, historical leakage and selection bias honestly; (5) the best first per-venture and comparison visualisations given the available evidence; and (6) the minimum reviewed data contract and acceptance criteria for new-venture entry and the next local release.
>
> Return confirmed strengths with evidence, material concerns, questions requiring Kevin's decision, and a prioritised research/implementation handover. If files or sources are unavailable, identify exactly which claims you cannot verify. Keep unsupported conclusions unresolved. This is a review and brainstorm request; do not implement, import, publish or contact anyone.
